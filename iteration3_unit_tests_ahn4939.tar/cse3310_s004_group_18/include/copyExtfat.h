#pragma once

#include "extfat.h"

int mmapCopy(fileInfo *inputFileInfo, char *output_file);
